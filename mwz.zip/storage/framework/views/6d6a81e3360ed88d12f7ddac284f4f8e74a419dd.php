<!DOCTYPE html>
<html lang="zxx" class="no-js">
<head>
    <!-- Mobile Specific Meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon-->
    <link rel="shortcut icon" href="<?php echo e(asset('img/fav.png')); ?>">
    <!-- Author Meta -->
    <meta name="author" content="colorlib">
    <!-- Meta Description -->
    <meta name="description" content="">
    <!-- Meta Keyword -->
    <meta name="keywords" content="">
    <!-- meta character set -->
    <meta charset="UTF-8">
    <!-- Site Title -->
    <title>App</title>

    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet">
    <!--
    CSS
    ============================================= -->
    <link rel="stylesheet" href="<?php echo e(asset('css/linearicons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/hexagons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">


    <meta property="og:url"           content="https://www.your-domain.com/your-page.html" />
    <meta property="og:type"          content="success" />
    <meta property="og:title"         content="morning wise" />
    <meta property="og:description"   content="morning wize" />
    <meta property="og:image"         content="" />
</head>
<body>


<?php echo $__env->yieldContent('content'); ?>




<script src="<?php echo e(asset('js/vendor/jquery-2.2.4.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('js/vendor/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.ajaxchimp.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/parallax.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.sticky.js')); ?>"></script>
<script src="<?php echo e(asset('js/hexagons.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.counterup.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>

</body>
</html>
<?php /**PATH C:\New folder (3)\mwz\resources\views/layout/master.blade.php ENDPATH**/ ?>